
import { createBrowserRouter,RouterProvider,} from "react-router-dom";
/*import Dashboard from "../view/Dashboard/index";*/
import Dashboard from "../view/Dashboard/app"
import Detail from "../view/Detail/index";

const router = createBrowserRouter([
    {
      path: "/",
      element: <Dashboard/>,
    },
    {
      path: "/Detail/:Id",
      element: <Detail/>,
    },
  ]);
  
  function Router () {
    return  <RouterProvider router={router} />
  }

export default Router;