
import './App.css';
import Router from "./config/router"
import Dashboard from './view/Dashboard/app';
import Detail from './view/Detail';

function App(){
return(
<div className='App' >
<div  className='App-header' >
<div  className='header'>
    <h1>Header</h1>
</div>
<Router/>
{/* <Dashboard/> */}
{/* <Detail/> */}
<div className='footer'  >
<h2>Footer</h2>
</div>
</div>
</div>
);
}
    

export default App;
