// import React from "react";
// /*import { useNavigate } from "react-router-dom";*/

// function Card(props){
// /*const navigate=useNavigate()*/
// const{name , brand,images , description , price , category}=props

// return(
// <>
// <div >
// <img   src={images}  />

// <div>
// <h1>
//     {name} <b>
//     {brand} <b>
//     {description} <b>
//     {price} <b>
//     {category}    
//     </b>   
//     </b>
//     </b>
//     </b>
// </h1>
// </div>

// </div>
// </>
// )
// }

// export default Card;

import React from "react";
import { useNavigate } from "react-router-dom";
import "./App.css"

function Card({ title, description, price, id, images }) {
  const navigate = useNavigate();

  return (
  <div class="col-md-3 mb-4  cards" >
      <div className="card" onClick={() => navigate(`detail/${id}`)} style={{width: '17rem' }}>
        <img src={images} className="card-img-top" alt="..." />
        <div className="card-body">
        <div className="titleDiv">
        <h5 class="card-title">Rs {price}</h5>
        <i class="fa-regular fa-heart "></i>
        </div>
        <br></br>
    <h6 class="card-subtitle mb-2 text-body-secondary">{description}</h6>

    <p class="card-text text-body-secondary m-0">Karachi, Pakistan</p>
    <p class="card-text text-body-secondary">5 days ago</p>
        </div>
      </div>
</div>
   



  );
}

export default Card;
