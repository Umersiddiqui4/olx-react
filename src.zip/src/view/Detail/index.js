// import { useEffect } from "react";
// import { useParams } from "react-router-dom";

// function Detail() {
//     const {adId} = useParams()


//     useEffect (() => {
//         getProductDetail()
//     })

//     const getProductDetail= () => {
//         fetch(`https://dummyjson.com/products${adId}`)
//         .then((res) => res.json())
//         .then(console.log)
//     }

//     return(
//         <div>
//             <h1>Detail</h1>
//         </div>
//     )
// }


// export default Detail;


import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
function Detail() {


  const { Id } = useParams();
  const [productDetail, setProductDetail] = useState(null);

  useEffect(() => {
    getProductDetail();
  }, [Id]);

  const getProductDetail = () => {
    console.log('adId:', Id);
    fetch(`https://dummyjson.com/products/${Id}`)
      .then((res) => res.json())
      .then((data) => {
        console.log(data);
        setProductDetail(data); // Set the fetched data to the state
      })
      .catch((error) => {
        console.error('Error fetching product:', error);
 });
  };

  if (!productDetail) {
    return <div>Loading...</div>;
  }

  const { title, description, price, category, images } = productDetail;

  return (
    <div className="detail">








      <div>
      <img className="d-i" src={images[0]} alt={title} />
      </div>
      <div className="details">
      <h2 className="d-t">{title}</h2>
      <p className="d-p">Price: {price}</p>
      <p className="d-c">Category: {category}</p>
      <p className="d-d">{description}</p>
      <button className="d-b">Add to Cart</button>
      </div>
      
  { /*   <UserProfile/>*/}
        
   </div>
  );
}

export default Detail;







