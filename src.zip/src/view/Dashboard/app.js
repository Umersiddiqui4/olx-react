
import Card from "../Card/index"
import { useState, useEffect } from "react";
/*import { useNavigate } from "react-router-dom";*/
function  Dashboard() {
   /*const navigate = useNavigate();*/
    const [Posts, setPosts] = useState([]);

    useEffect(() => {
        getPostFromAPI();
      }, []);
    
      function getPostFromAPI() {
        fetch("https://dummyjson.com/products")
          .then((res) => res.json())
          .then((res) => {
            setPosts(res.products);
          });
      }console.log(Posts)

      if (!Posts.length) {
      return  <div>
          <img src='https://i.pinimg.com/originals/c7/e1/b7/c7e1b7b5753737039e1bdbda578132b8.gif' />
        </div>
      }
    return (
    
        <div /*className="card" */ /*style={{ backgroundColor:"black"  ,display:"flex" , flexwrap:"wrap" , alignItems:"left" , maxWidth:"100%" ,
         height:"50%" ,marginBottom:"8px" , border:"1px solid" ,borderRadius:"8px" , padding:"16px" , 
      margin :"16px" , width:"50px" , height:"250px" , textAlign:"left" , boxShadow:"0, 4px,8px"
      

      }}*/   >  


   
<div class="container-fluid text-center">
  <div class="row">
       {Posts.map((item)=>(
         < Card 
             id={item.id}
              name={item.title}
              brand={item.brand}
              description={item.description}
              price={item.price}
              images={item.thumbnail }
              discountPercentage={item.discountPercentage}
              category={item.category}
              />
            ))}
        </div>
         </div>
       </div>
    )
}

export default Dashboard;